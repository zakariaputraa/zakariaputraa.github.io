/*instafeed*/
var feed = new Instafeed({
  target: "globalCar",
  accessToken: 'IGQVJYalZAFXzhiWEhTN2NaaW9uclRXOVMtMThUdHlSQUFPS3Q2VHB3ZA0lPNzJmajd3THloZAkdFVWFrNGZABa0FBb3N2RXdLSmI2OG1CSU1kUy1HU1E4ZAUhMd3dBTC03THF1c0luRmtWQi14YkZAXWEZAuVgZDZD',
  template: '<div class="items"><img title="{{caption}}" src="{{image}}" /><div class="overlay">{{caption}}</div><a href="{{image}}" data-fancybox="images" data-caption="{{caption}}" class="view-image"></a><a href="{{link}}" class="view-post" target="_blank"></a></div>', 
   after: function() {
      $(".overlay").text(function(index, currentText) {
          return currentText.substr(0, 180);
      });

      $(".carousel.global").owlCarousel({	
          loop: false,	
          margin: 0,
          center: false,
          autoplay: false,
          nav: true,
          navText: [" "," "],
          dots: false,
          responsiveClass: true,
          responsive:{
              0:{items:1},
              1000:{items:4},
          }
      });
   },
});
feed.run();

var feed2 = new Instafeed({
	target: "globalGrid",
  accessToken: 'IGQVJYalZAFXzhiWEhTN2NaaW9uclRXOVMtMThUdHlSQUFPS3Q2VHB3ZA0lPNzJmajd3THloZAkdFVWFrNGZABa0FBb3N2RXdLSmI2OG1CSU1kUy1HU1E4ZAUhMd3dBTC03THF1c0luRmtWQi14YkZAXWEZAuVgZDZD',
  template: '<div class="items"><img title="{{caption}}" src="{{image}}" /><div class="overlay">{{caption}}</div><a href="{{image}}" data-fancybox="images" data-caption="{{caption}}" class="view-image"></a><a href="{{link}}" class="view-post" target="_blank"></a></div>', 
   after: function() {
      $(".overlay").text(function(index, currentText) {
          return currentText.substr(0, 180);
      });
   },
});
feed2.run();